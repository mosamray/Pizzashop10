package com.company;

import java.util.*;

public class Order {
    //Class Level Variables - Protect the data
    private int orderId;
    private Customer cust;
    private ArrayList<Menu> menuItem;


    //Constructor Method
    public Order(int _orderId) { this.orderId = _orderId; }


    //Setters and Getters
    public int getOrderId() {
        return orderId;
    }
    public void setOrderId(int _orderId){this.orderId = _orderId;}

    public static void listOrder(ArrayList<Order> oList) {
        for (Order order: oList){
            System.out.println("order ID: 1");
            System.out.println("Order Name: Super veg");
            System.out.println("Customer Name: Mary Smith");
            System.out.println("Customer phoneNumber: 215-965-8965");
            System.out.println("payment type: cash");
        }
    }

    }











