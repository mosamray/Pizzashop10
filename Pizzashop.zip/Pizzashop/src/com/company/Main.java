package com.company;

/*
Project: Lab 9
Purpose Details: Pizza shop application
Course: IST 242
Author: Mosam Ray
Date Developed: 3/13/19
Last Date Changed: 3/12/19
Rev: 2
 */

import java.util.ArrayList;
import java.util.Scanner;

        public class Main {

            public static void main(String[] args) {

                final char EXIT_CODE = 'E';
                final char CUST_CODE = 'C';
                final char MENU_CODE = 'M';
                final char ORDE_CODE = 'O';
                final char TRAN_CODE = 'T';
                final char CUST_PRNT = 'p';
                final char HELP_CODE = '?';
                char userAction;
                final String PROMPT_ACTION = "Add 'C'ustomer, List 'M'enu, Add 'O'rder, List 'T'ransaction or 'E'xit: ";
                ArrayList<Customer> cList = new ArrayList<>();
                ArrayList<Menu> mList = new ArrayList<>();
                ArrayList<Order> oList = new ArrayList<>();
                ArrayList<Transaction> tList = new ArrayList<>();

                Customer cust1 = new Customer(1, "Mary Smith", "215-965-8965");
                Customer cust2 = new Customer(2, "Teddy Jones", "215-862-7415");
                Order order1 = new Order(1);
                Transaction trans1 = new Transaction(1,"Cash");


                Menu menu1;
                menu1 = new Menu(1, "Double cheese");
                Menu menu2;
                menu2 = new Menu(2, "Pacific veg");
                Menu menu3;
                menu3 = new Menu(3, "Extra meat");
                Menu menu4;
                menu4 = new Menu(4, "Super Veg");

                mList.add(menu1);
                mList.add(menu2);
                mList.add(menu3);
                mList.add(menu4);

                cList.add(cust1);
                oList.add(order1);
                tList.add(trans1);

                userAction = getAction(PROMPT_ACTION);

                while (userAction != EXIT_CODE) {
                    switch(userAction) {
                        case CUST_CODE : Customer.listCustomer(cList);
                            break;
                        case MENU_CODE : Menu.listMenu(mList);
                            break;
                        case ORDE_CODE : Order.listOrder(oList);
                            break;
                        case TRAN_CODE : Transaction.listTransaction(tList);
                            break;
                    }

                    userAction = getAction(PROMPT_ACTION);
                }
            }


            public static char getAction(String prompt) {
                Scanner scnr = new Scanner(System.in);
                String answer = "";
                System.out.println(prompt);
                answer = scnr.nextLine().toUpperCase() + " ";
                char firstChar = answer.charAt(0);
                return firstChar;
            }
        }





