package com.company;

import java.util.ArrayList;

public class Customer {
    //Class Level Variables - Protect the data
    private int customerId;
    private String CustomerName;
    private String CustomerPhoneNumber;

    //Constructor Method
    public Customer(int _customerId, String _CustomerName, String _CustomerPhoneNumber){
        this.customerId++;
        this.CustomerName = _CustomerName;
        this.CustomerPhoneNumber = _CustomerPhoneNumber;
    }

    //Setters and Getters
    public int getCustomerId() { return customerId; }
    public void setCustomerId(int _customerId) { this.customerId = _customerId; }

    public String getCustomerName() { return CustomerName; }
    public void setCustomerName(String _customerName) { this.CustomerName = _customerName; }

    public String getCustomerPhoneNumber() { return CustomerPhoneNumber; }
    public void setCustomerPhoneNumber(String _customerPhoneNumber) { this.CustomerPhoneNumber = _customerPhoneNumber; }

    public static void listCustomer(ArrayList<Customer> cList){
        for (Customer cust: cList){
            System.out.println("Customer Id: " + cust.getCustomerId());
            System.out.println("Customer Name: " + cust.getCustomerName());
            System.out.println("Customer phone: " + cust.getCustomerPhoneNumber());
        }
    }

   }


