package com.company;

import java.util.ArrayList;

enum paymentType {cash, credit}

public class Transaction {
    //Class Level Variables - Protect the data
    private int transactionId;
    private Order order;
    private paymentType pType;

    public Transaction(paymentType pType) {
        this.pType = pType;
    }

    //Constructor Method
    public Transaction(int i, String _pType) {
        this.transactionId = transactionId;
    }


    //Setters and Getters
    public int getTransactionId() { return transactionId; }
    public void setTransactionId(int _transactionId) { this.transactionId = _transactionId; }

    public Order getOrder() { return order; }
    public void setOrder(Order _order) { this.order = _order; }

    public paymentType getpaymentType() { return pType; }
    public void setpaymentType(paymentType _pType) { this.pType = _pType; }

    public static void listTransaction(ArrayList<Transaction> tList) {
        for (Transaction trans: tList){
            System.out.println("Transaction ID: 1");
            System.out.println("Order: Super veg");
            System.out.println("Payment Type: cash");
        }
    }
}



